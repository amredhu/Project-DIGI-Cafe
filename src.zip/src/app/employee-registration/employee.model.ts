export interface Employee {
  employeeId: String;
  phoneNumber : number;
  employeeName: String;
  dateOfBirth : Date;
  employeeEmail: String;
  password: String;
  securityQuestion: String;
  securityAnswer: String;
  }
