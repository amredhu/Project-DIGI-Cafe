import { Employee } from './employee.model';
import { EmployeeService } from './employee.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-employee-registration',
  templateUrl: './employee-registration.component.html',
  styleUrls: ['./employee-registration.component.css']
})
export class EmployeeRegistrationComponent implements OnInit {

  constructor(private empSrv: EmployeeService ) { }

  ngOnInit() {
  }
 employee : Employee ={"employeeId" : "" ,"phoneNumber":0, "employeeName":"","dateOfBirth":new Date(),"employeeEmail":"","password":"" ,"securityQuestion":"","securityAnswer":""};
  saveEmployee()
  {
  this.empSrv.saveEmployee(this.employee).subscribe(
  data => console.log(data),
  error => console.log(error)
  );
  }

}
