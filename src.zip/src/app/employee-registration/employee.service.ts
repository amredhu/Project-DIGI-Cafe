import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Employee} from './employee.model'
import { Router } from '@angular/router';
@Injectable({
providedIn: 'root'
})
export class EmployeeService{

constructor(private http: HttpClient,private routerDemo: Router) {
}
saveEmployee(employee: Employee) {
alert('register success');
this.routerDemo.navigateByUrl('/emplogin');
return this.http.post<any>('http://localhost:1008/employee', employee);

}

}
