import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmpComponent } from './emp/emp.component';
import { LoginComponent } from './login/login.component';
import { AdminComponent } from './admin/admin.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LoginshopownerComponent } from './loginshopowner/loginshopowner.component';
import { MenushopownerComponent } from './menushopowner/menushopowner.component';
import { EmployeeRegistrationComponent } from './employee-registration/employee-registration.component';
import { EmployeeLoginComponent } from './employee-login/employee-login.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { EmployeehomeComponent } from './employeehome/employeehome.component';
import { ConfirmComponent } from './confirm/confirm.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { AnalysisComponent } from './analysis/analysis.component';
import { OrdersComponent } from './orders/orders.component';
import { ProfileComponent } from './profile/profile.component';
import {OrdersShopComponent} from './ordershop/ordershop.component';
import { OrderempComponent } from './orderemp/orderemp.component'
// import { ModelComponent } from './model/model.component';

@NgModule({
  declarations: [
    AppComponent,
    EmpComponent,
    LoginComponent,
    AdminComponent,
    LoginshopownerComponent,
    MenushopownerComponent,
    EmployeeRegistrationComponent,
    EmployeeLoginComponent,
    ForgotpasswordComponent,
    EmployeehomeComponent,
    ConfirmComponent,
    ChangepasswordComponent,
    AnalysisComponent,
    OrdersComponent,
    OrdersShopComponent,
    ProfileComponent,
    OrderempComponent,
    // ModelComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
