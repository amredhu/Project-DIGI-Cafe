export interface Food{
    foodItem:string;
    quantity:number;
    bill:number;
  }