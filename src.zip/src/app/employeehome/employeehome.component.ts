import { Component, OnInit } from '@angular/core';
import {shops} from './employeeHome.model';
 import {EmployeeHomeService} from './employeeHome.service'
@Component({
  selector: 'app-employeehome',
  templateUrl: './employeehome.component.html',
  styleUrls: ['./employeehome.component.css']
})
export class EmployeehomeComponent implements OnInit {
  menu: shops ={"shopName" : "" , "menuId":"","foodItem":"","price":"" ,"name":""};
  constructor(private shopSrv:EmployeeHomeService,private menuSrv:EmployeeHomeService) { }
 s: shops[] = [];
  ngOnInit() {
    this.getShops();

  }
  shop1 : shops[] = [];
  getShops() {
  this.shopSrv.getShops().subscribe(
  data => this.shop1 = data,
  error => console.log(error)
  );
  }
  getFood(shopName: string) {
    this.menuSrv.getFoods(shopName).subscribe(
    data => this.s = data,
    error => console.log(error)
    );
    }




}
