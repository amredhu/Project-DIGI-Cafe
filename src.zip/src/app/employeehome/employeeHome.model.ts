// tslint:disable-next-line: class-name
import {Food} from './food.model';
export interface shops {
  shopName: string;
   menuId: string;
   foodItem: string;
   price: string;
   name: string;
  }
  export interface Order{
    employeeId:string;
    orderId:string;
    shopName:string;
    food:Food[];
    total;
    status:string;
  }
