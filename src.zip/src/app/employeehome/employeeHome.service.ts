import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {shops} from './employeeHome.model';
@Injectable({
  providedIn: 'root'
})
export class EmployeeHomeService {

  constructor(private http:HttpClient) { }
  getShops() {
    return this.http.get<shops[]>('http://localhost:1008/shops');
    }
    getFoods(shopName: string) {
      return this.http.get<shops[]>(`http://localhost:1008/menu/${shopName}`);
      }

}
