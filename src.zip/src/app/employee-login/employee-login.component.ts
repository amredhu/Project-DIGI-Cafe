import { Component, OnInit } from '@angular/core';
import {loginEmployeeService} from './employee-login.service';
import {loginEmployee } from './employee.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-login',
  templateUrl: './employee-login.component.html',
  styleUrls: ['./employee-login.component.css']
})
export class EmployeeLoginComponent implements OnInit {

  employeeId:string;
  password: string;
  ret1: string;
  ret2: string;
  ret3:string;
  // ret4: Date;

  constructor(private loginSrv:loginEmployeeService, private rout: Router) { }

  ngOnInit() {
  }
  // login: LoginshopownerService ={"usersName" : "" , "password":""};

  validate() {
    this.loginSrv.validate(this.employeeId,this.password).subscribe(
    data => {this.ret1 = Object.values(data)[0];
      this.ret2 = Object.values(data)[1];
      // localStorage.setItem('emp', this.ret1);
      // localStorage.setItem('empId', this.ret2);
      // localStorage.setItem('phoneNo', this.ret3);
      localStorage.setItem("employeeIdLogin",this.employeeId);
      console.log(this.employeeId);
      this.rout.navigateByUrl('/profile');

       //console.log(localStorage.getItem('shopName'));
    },
    
    error => {
      alert("Nothing");
      console.log(error);
    this.rout.navigateByUrl('/emplogin');
  }
    );

   
}
}
