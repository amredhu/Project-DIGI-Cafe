export interface loginEmployee{
    employeeId: string;
    password: string;
}