import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { loginEmployee } from './employee.model';
@Injectable({
  providedIn: 'root'
})
// tslint:disable-next-line: class-name
export class loginEmployeeService {

  constructor(private http: HttpClient) { }
  validate(employeeId: string,password: string) {
    return this.http.get<loginEmployee>(`http://localhost:1008/employee/${employeeId}/${password}`);
    }
}
