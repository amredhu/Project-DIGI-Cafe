import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginshopownerComponent } from './loginshopowner.component';

describe('LoginshopownerComponent', () => {
  let component: LoginshopownerComponent;
  let fixture: ComponentFixture<LoginshopownerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginshopownerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginshopownerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
