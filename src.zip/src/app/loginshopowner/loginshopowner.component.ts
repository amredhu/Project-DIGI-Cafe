import { Loginshop } from './loginshop.model';
import { Component, OnInit } from '@angular/core';
import { LoginshopownerService} from './loginshopowner.service'
import { Loginshopowner } from './loginshopowner.model';
import { Router } from '@angular/router';
@Component({
  selector: 'app-loginshopowner',
  templateUrl: './loginshopowner.component.html',
  styleUrls: ['./loginshopowner.component.css']
})
export class LoginshopownerComponent implements OnInit {
  usersName:string;
  password: string;
  ret:string;

  constructor(private loginSrv:LoginshopownerService, private rout: Router) { }

  ngOnInit() {
  }
  // login: LoginshopownerService ={"usersName" : "" , "password":""};

  login1() {
    this.loginSrv.login(this.usersName,this.password).subscribe(
    data => {this.ret = Object.values(data)[2];
      localStorage.setItem('shopName', this.ret);
      console.log(localStorage.getItem('shopName'));
      this.rout.navigateByUrl('shopowner');
    },
    error => console.log(error)
    );

    

}
}
