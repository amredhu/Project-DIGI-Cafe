
export interface Loginshop {
 username : String;
 password : String;
 }
