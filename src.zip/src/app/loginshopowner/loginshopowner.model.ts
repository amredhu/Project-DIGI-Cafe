export interface Loginshopowner{
  usersName: string;
  password: string;
}
