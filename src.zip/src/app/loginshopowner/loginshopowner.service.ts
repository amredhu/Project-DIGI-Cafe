import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Loginshopowner } from './loginshopowner.model';
@Injectable({
  providedIn: 'root'
})
export class LoginshopownerService {

  constructor(private http: HttpClient) { }
  login(usersName: String,password: String) {
    return this.http.get<Loginshopowner>(`http://localhost:1008/shops/${usersName}/${password}`);
    }
}
