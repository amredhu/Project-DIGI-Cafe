

export interface forgot{
    employeeId: string;
    employeeName: string;
    phoneNumber: string;
    employeeEmail: string;
    dateOfBirth: Date;
    password:string;
    securityQuestion: string;
    securityAnswer: string;
    

}