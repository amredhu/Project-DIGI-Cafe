import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { forgot } from './forgotpassword.model';

@Injectable({
  providedIn: 'root'
})
export class ForgotService {

  constructor(private http: HttpClient) { }
  updatePass(employeeId: string, securityAnswer:string){
      return this.http.get<boolean>(`http://localhost:1008/employees/${employeeId}/${securityAnswer}`)
  }

}