import { Component, OnInit } from '@angular/core';
import { elementStyleProp } from '@angular/core/src/render3';
import { ForgotService } from './forgotpassword.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {

  constructor( private forgotService: ForgotService, private router:Router) { }
  securityQuestion;
  securityAnswer;
  employeeId;
  a:boolean;
  ngOnInit() {
    
  }

  checkAnswer(){
    localStorage.setItem('employeeId', this.employeeId);
    this.forgotService.updatePass(this.employeeId,this.securityAnswer).subscribe(
      data=>{this.a = data;
        if (this.a){
          this.router.navigateByUrl('/changepassword');
        }
       else if(this.a === false) {
        alert('Incorrect Details');
        }},
      error=>console.log(error)
    );
     

  }

  
    
  
  
 
}
