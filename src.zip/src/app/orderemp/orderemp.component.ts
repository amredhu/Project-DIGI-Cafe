import { Component, OnInit } from '@angular/core';
import {Order} from './orderemp.model';
import {Food} from './menufood.model';
import {OrderempService} from './orderemp.service';

@Component({
  selector: 'app-orderemp',
  templateUrl: './orderemp.component.html',
  styleUrls: ['./orderemp.component.css']
})
export class OrderempComponent implements OnInit {

  food:Food[]=[];
  order :Order={"employeeId":"","orderId":"","shopName":"","food":this.food,"total":"","status":"in progress"};
  constructor(private ordSrv:OrderempService) { }
  ord:Order[]=[];
  ngOnInit() {
    this.order.employeeId= localStorage.getItem('employeeIdLogin');
    //alert(this.order.employeeId);
    this.getOrderName(this.order.employeeId);
  }
  getOrderName(employeeId:string){
    this.ordSrv.getOrderName(employeeId).subscribe(
      data=>{this.ord = data;
      console.log(this.ord[0].food)},
      error=>console.log(error)
    );
  
  }

}