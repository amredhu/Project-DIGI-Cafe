import {Food} from './menufood.model'
export interface Order{
    employeeId:string;
    orderId:string;
    shopName:string;
    food:Food[];
    total;
    status:string;
  }