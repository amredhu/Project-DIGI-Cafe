import { TestBed } from '@angular/core/testing';

import { OrderempService } from './orderemp.service';

describe('OrderempService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: OrderempService = TestBed.get(OrderempService);
    expect(service).toBeTruthy();
  });
});
