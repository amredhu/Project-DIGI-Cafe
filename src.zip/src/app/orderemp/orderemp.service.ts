import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Order } from './orderemp.model';

@Injectable({
  providedIn: 'root'
})
export class OrderempService {

  constructor(private http:HttpClient) { }

  getOrderName(employeeId:string){
    return this.http.get<Order[]>(`http://localhost:1008/orders/${employeeId}`);
  }
}
