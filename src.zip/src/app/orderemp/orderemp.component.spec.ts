import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderempComponent } from './orderemp.component';

describe('OrderempComponent', () => {
  let component: OrderempComponent;
  let fixture: ComponentFixture<OrderempComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderempComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderempComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
