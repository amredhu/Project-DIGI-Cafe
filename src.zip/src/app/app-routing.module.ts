import { MenushopownerComponent } from './menushopowner/menushopowner.component';
import { AdminComponent } from './admin/admin.component';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmpComponent } from './emp/emp.component';
import { LoginshopownerComponent } from './loginshopowner/loginshopowner.component';
import { EmployeeLoginComponent } from './employee-login/employee-login.component';
import { EmployeeRegistrationComponent } from './employee-registration/employee-registration.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { EmployeehomeComponent } from './employeehome/employeehome.component';
import { ConfirmComponent } from './confirm/confirm.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { AnalysisComponent } from './analysis/analysis.component';
import { OrdersComponent } from './orders/orders.component';
import { ProfileComponent } from './profile/profile.component';
import { OrdersShopComponent } from './ordershop/ordershop.component';
import { OrderempComponent } from './orderemp/orderemp.component';
// import { ModelComponent } from './model/model.component';

const routes: Routes = [
{path: '',
redirectTo: 'emp',
pathMatch: 'full'
},
{path: 'adminhome' , component: AdminComponent},
   {path: 'emp', component: EmpComponent},
  { path: 'login', component: LoginComponent},
  { path: 'loginshop', component: LoginshopownerComponent },
  { path: 'shopowner', component: MenushopownerComponent },
  { path: 'emplogin', component: EmployeeLoginComponent },
  { path: 'rest', component: EmployeeRegistrationComponent },
  {path: 'registration',component:EmployeeRegistrationComponent},
  {path: 'forgotpassword',component:ForgotpasswordComponent},
{path: 'employeeHome' ,component:EmployeehomeComponent},
{path: 'confirm',component:ConfirmComponent},
{path: 'changepassword', component:ChangepasswordComponent},
{path: 'kavya', component:AnalysisComponent},
{path: 'orders', component:OrdersComponent},
{path: 'profile', component:ProfileComponent},
{path:'ordershop', component:OrdersShopComponent},
{path:'orderemp', component:OrderempComponent}
// {path: 'model', component:ModelComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
