import {Food} from './food.model';

export interface shops {
    shopName: string;
     menuId: string;
     foodItem: string;
     price: string;
     name: string;
    }



export interface employeeDb{
     
    employeeId:string;
    employeeName:string;
    phoneNumber:string;
   employeeEmail:string;
    dateOfBirth:Date;
    password:string;
    securityQuestion:string;
    securityAnswer:string;
   
}
export interface Order{
    employeeId:string;
    orderId:string;
    shopName:string;
    food:Food[];
    total;
    status:string;
  }