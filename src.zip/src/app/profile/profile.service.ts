import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { employeeDb,Order,shops } from './profile.model';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {

  constructor(private http:HttpClient) { }

  getEmployee(employeeId:string){
    return this.http.get<employeeDb>(`http://localhost:1008/employee/${employeeId}`);
  }
  getShops() {
    return this.http.get<shops[]>('http://localhost:1008/shops');
    }
    getFoods(shopName: string) {
      return this.http.get<shops[]>(`http://localhost:1008/menu/${shopName}`);
      }
saveOrder(order: Order) {
          alert('saved');
          return this.http.post<any>('http://localhost:1008/order', order);
          }
        getOrder(employeeId:string){
          return this.http.get<Order[]>(`http://localhost:1008/order/${employeeId}`);
        }


}
