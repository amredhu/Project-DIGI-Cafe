import { Component, OnInit } from '@angular/core';
import { employeeDb,shops,Order } from './profile.model';
import { ProfileService } from './profile.service';

import { Inject }  from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { Food } from './food.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  empDb:employeeDb={"employeeId":"",
  "employeeName":"",
  "phoneNumber":"",
  "employeeEmail":"",
  "dateOfBirth":new Date(),
  "password":"",
  "securityQuestion":"",
  "securityAnswer":""
};
food:Food[]=[];
 order :Order={"employeeId":"","orderId":"","shopName":"","food":this.food,"total":"","status":"in progress"};

menu: shops ={"shopName" : "" , "menuId":"","foodItem":"","price":"" ,"name":""};
p:employeeDb[]=[];

  constructor(private profileService:ProfileService,@Inject(DOCUMENT) document,private shopSrv:ProfileService,private menuSrv:ProfileService,private proSrv:ProfileService,private ordSrv:ProfileService,private rout: Router) { }

  ngOnInit() {
    this.empDb.employeeId=localStorage.getItem('employeeIdLogin');
    this.getShops();

    this.order.employeeId=localStorage.getItem('employeeIdLogin');
    //alert(localStorage.getItem('employeeIdLogin'));
  }
  shop1:shops[]=[];
  o:Order[]=[];
  ord:Order[]=[];
  s:shops[]=[];
emp:employeeDb={"employeeId":"","employeeName":"","employeeEmail":"","phoneNumber":"","password":"","securityQuestion":"","securityAnswer":"","dateOfBirth":new Date()};

getShops() {
  this.shopSrv.getShops().subscribe(
  data => this.shop1 = data,
  error => console.log(error)
  );
  }

  getFood(shopName: string) {

    this.total=0;
    
    
        this.menuSrv.getFoods(shopName).subscribe(
        data => {this.s = data; this.quantity=new Array(this.s.length); this.quantity.fill(0) },
        error => console.log(error)
        );
        }
        ctr:number=0;

        quantity:number[]=[];

        total:number=0;

    totalArr:number[]=[];





  getEmployee(employeeId:string){
    console.log(this.empDb.employeeId)
    this.profileService.getEmployee(this.empDb.employeeId).subscribe(
      data=>{this.emp=data;
        
      },
      error=>console.log(error)
    );

  }
  countFun()
    {
     let i:number=0;
      for(let test of this.s)
      {
      this.total=this.total+ parseInt( (<HTMLInputElement>document.getElementById('total'+i)).value);
      this.totalArr[i]=parseInt( (<HTMLInputElement>document.getElementById('total'+i)).value);
      i=i+1;

      }
    }
  

saveOrder()
{
let i=0;
  for(let foodItem of this.s)
  {
  let food:Food={"foodItem":foodItem.foodItem, "quantity":this.quantity[i],"bill":this.totalArr[i]};
 this.order.food[i]=food;
i=i+1;
this.order.shopName=foodItem.shopName;
this.order.total=this.total;
}
  for(let f of this.s){
  this.order.orderId=this.empDb.employeeId+(f.shopName).substring(0,2)+f.foodItem.substring(1,2);
  localStorage.setItem('em',this.empDb.employeeId) ;
  localStorage.setItem('orderId',this.order.orderId);
  localStorage.setItem('sname',f.shopName);
  localStorage.setItem('totalBill',this.total.toString());
  this.rout.navigateByUrl('/orders');
  // this.order.shopeName=f.shopName;
  }
  this.ordSrv.saveOrder(this.order).subscribe(
 data => console.log(data),
 error => console.log(error)
 );
}

getOrder(employeeId: string) {
  this.proSrv.getOrder(employeeId).subscribe(
  data => this.o = data,
  error => console.log(error)
  );

  }
  

}
