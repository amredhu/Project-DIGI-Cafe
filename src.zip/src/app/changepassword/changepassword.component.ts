import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ChangePasswordService } from './change-password.service';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {

  constructor(private routerDemo: Router, private changepass:ChangePasswordService) { }

  ngOnInit() {
  }

  username;
  password;
  validate(){
    if (this.username===this.password){
      const empId=localStorage.getItem('employeeId');
      this.changepass.updatePass(empId,this.username).subscribe(
        data=>console.log(data),
        error=>console.log(error)

      );
      alert("Password Changed");
      this.routerDemo.navigateByUrl('/emplogin');
    }
    else{
      alert("Passwords dont match");
    }
  }

}
