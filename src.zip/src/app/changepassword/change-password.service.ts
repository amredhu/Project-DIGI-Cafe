import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ChangePasswordService {

  constructor(private http:HttpClient) { }

  updatePass(employeeId:string,pass:string){
   return this.http.put<any>(`http://localhost:1008/employee/${employeeId}/${pass}`,employeeId);

  }
}
