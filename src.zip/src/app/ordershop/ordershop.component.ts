import { Component, OnInit } from '@angular/core';
import {Order} from './ordershop.model';
import {Food} from './menufood.model';
import {OrderService} from './ordershop.service';
@Component({
  selector: 'app-orders',
  templateUrl: './ordershop.component.html',
  styleUrls: ['./ordershop.component.css']
})
export class OrdersShopComponent implements OnInit {
  food:Food[]=[];
  order :Order={"employeeId":"","orderId":"","shopName":"","food":this.food,"total":"","status":"in progress"};
  constructor(private ordSrv:OrderService) { }
  ord:Order[]=[];
  ngOnInit() {
    this.order.shopName= localStorage.getItem('shopName');
    //alert(this.order.shopName);
    this.getOrderName(this.order.shopName);
  }
  getOrderName(shopName:string){
    this.ordSrv.getOrderName(shopName).subscribe(
      data=>this.ord = data,
      error=>console.log(error)
    );
  
  }

}
