import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrdersShopComponent } from './ordershop.component';

describe('OrdersComponent', () => {
  let component: OrdersShopComponent;
  let fixture: ComponentFixture<OrdersShopComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [OrdersShopComponent]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrdersShopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
