import { Shop } from './../admin/admin.model';
 import { Injectable } from '@angular/core';
 import { HttpClient } from '@angular/common/http';
 import {Order} from './ordershop.model';
 @Injectable({
 providedIn: 'root'
})
 export class OrderService {

 constructor(private http: HttpClient) {
 }
 
 getOrderName(shopName:string){
    return this.http.get<Order[]>(`http://localhost:1008/order/${shopName}`);
  }

 }
