import { Shop } from './../admin/admin.model';
 import { Menudb ,Order} from './menushopowner.model';
 import { MenuService } from './menushopowner.service';
 import { Component, OnInit } from '@angular/core';
import {Food} from '../ordershop/menufood.model'
 @Component({
   selector: 'app-menushopowner',
   templateUrl: './menushopowner.component.html',
   styleUrls: ['./menushopowner.component.css']
 })
 export class MenushopownerComponent implements OnInit {

  menu: Menudb ={"shopName" : "" , "menuId":"","foodItem":"","price":"" };
  food:Food[]=[];
 order :Order={"employeeId":"","orderId":"","shopName":"","food":this.food,"total":"","status":"in progress"};

  constructor(private menuSrv: MenuService,private ordSrv:MenuService) { }
ord:Order[]=[];
   ngOnInit() {
     this.menu.shopName = localStorage.getItem('shopName');
   }
   savefoodItem()
 {
  this.menuSrv.savefoodItem(this.menu).subscribe(
 data => console.log(data),
 error => console.log(error)
 );
 }



 updatefoodItem() {

 this.menuSrv.updatefoodItem(this.menu.foodItem, this.menu).subscribe(
 data => console.log(data),
 error => console.log(error)
 );
 }



 deletefood() {

 this.menuSrv.deleteFood(this.menu.menuId).subscribe(
 data => console.log(data),
 error => console.log(error)
 );
 }


 getFood() {

 //this.resturant.resturantId=2;
 this.menuSrv.getFood(this.menu.shopName, this.menu.foodItem).subscribe(
 data => this.menu = data,
 error => console.log(error)
 );
 }

 menus : Menudb[] = [];
 getFoods() {
 this.menuSrv.getFoods(this.menu.shopName).subscribe(
 data => this.menus = data,
 error => console.log(error)
 );


 }
 getOrderName(shopName:string){
  this.ordSrv.getOrderName(shopName).subscribe(
    data=>this.ord=data,
    error=>console.log(error)
  );

}


 }
