 import {Food} from '../ordershop/menufood.model';
 export interface Menudb {
   shopName: string;
   menuId: string;
   foodItem: string;
   price: string;
  }
  export interface Order{
    employeeId:string;
    orderId:string;
    shopName:string;
    food:Food[];
    total;
    status:string;
  }

