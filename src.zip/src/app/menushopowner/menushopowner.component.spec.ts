 import { async, ComponentFixture, TestBed } from '@angular/core/testing';

 import { MenushopownerComponent } from './menushopowner.component';

 describe('MenushopownerComponent', () => {
   let component: MenushopownerComponent;
  let fixture: ComponentFixture<MenushopownerComponent>;



   beforeEach(async(() => {
     TestBed.configureTestingModule({
       declarations: [ MenushopownerComponent ]
     })
     .compileComponents();
   }));

   beforeEach(() => {
    fixture = TestBed.createComponent(MenushopownerComponent);
     component = fixture.componentInstance;
     fixture.detectChanges();
   });

   it('should create', () => {
     expect(component).toBeTruthy();
   });
 });
