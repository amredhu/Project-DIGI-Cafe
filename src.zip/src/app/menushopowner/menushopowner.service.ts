import { Shop } from './../admin/admin.model';
 import { Injectable } from '@angular/core';
 import { HttpClient } from '@angular/common/http';
 import { Menudb,Order } from './menushopowner.model';
 import {Food} from '../ordershop/menufood.model';
 @Injectable({
 providedIn: 'root'
})
 export class MenuService {

 constructor(private http: HttpClient) {
 }
 savefoodItem(menu: Menudb) {
 alert('saved');
 return this.http.post<any>('http://localhost:1008/menu', menu);
 }


 updatefoodItem(foodItem:string, menu: Menudb) {
 return this.http.put<Menudb>(`http://localhost:1008/menu/${foodItem}`, menu);

 }

 getFoods(shopName:string) {
 return this.http.get<Menudb[]>(`http://localhost:1008/menu/${shopName}`);
 }


 deleteFood(Id: string) {
 return this.http.delete(`http://localhost:1008/menu/${Id}`);
 }

getFood(shopName: string,foodItem:string) {
 return this.http.get<Menudb>(`http://localhost:1008/menu/${foodItem}/${shopName}`);
 }
 getOrderName(shopName:string){
    return this.http.get<Order[]>(`http://localhost:1008/order/${shopName}`);
  }

 }
