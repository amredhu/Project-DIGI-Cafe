import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Shop } from './admin.model';
@Injectable({
providedIn: 'root'
})
export class ShopService {

constructor(private http: HttpClient) {
}
saveShop(shop: Shop) {
alert('saved');
return this.http.post<any>('http://localhost:1008/shops', shop);
}


updateShop(cuisine: string,shop:Shop) {
return this.http.put<Shop>(`http://localhost:1008/shops/${cuisine}`,shop);

}

getShops() {
return this.http.get<Shop[]>('http://localhost:1008/shops');
}


deleteShop(shopName: string) {
return this.http.delete(`http://localhost:1008/shops/${shopName}`);
}

getShop(shopName: string) {
return this.http.get<Shop>(`http://localhost:1008/shops/${shopName}`);
}

}
