export interface Shop {
  usersName: string;
  password: string;
  shopName: string;
  cuisine: string;
  }
