import { Shop } from './admin.model';
import { ShopService } from './admin.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private shopSrv: ShopService) { }

  ngOnInit() {
  }
  shop: Shop ={"usersName" : "" , "password":"","shopName":"","cuisine":"" };
saveShop()
{
this.shopSrv.saveShop(this.shop).subscribe(
data => console.log(data),
error => console.log(error)
);
}


updateShop() {

  console.log(this.shop.usersName)

this.shopSrv.updateShop(this.shop.shopName,this.shop).subscribe(
data => console.log(data),
error => console.log(error)
);
}



deleteShop() {

this.shopSrv.deleteShop(this.shop.shopName).subscribe(
data => console.log(data),
error => console.log(error)
);
}


getShop() {

// this.resturant.resturantId=2;
this.shopSrv.getShop(this.shop.shopName).subscribe(
data => this.shop = data,
error => console.log(error)
);
}

  shops : Shop[] = [];
  getShops() {
  this.shopSrv.getShops().subscribe(
  data => this.shops = data,
  error => console.log(error)
  );


  }
}

