import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {

  constructor() { }
  o:string;
  s:string;
  t:string;
  e:string;
  ngOnInit() {
    this.o=localStorage.getItem('orderId');
    this.s=localStorage.getItem('sname');
    this.t=localStorage.getItem('totalBill');
    this.e=localStorage.getItem('em');
    // alert("order confirmed"+"orderId:"+this.o+"sname:"+this.s+"totalBill:"+this.t);

  }
  print(){
    window.print();
  }
}
